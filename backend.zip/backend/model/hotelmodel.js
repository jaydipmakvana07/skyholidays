const db = require('../connection');

exports.getAllHotels = (callback) => {
  db.query('SELECT * FROM hotels', callback);
};


exports.createHotels = (hotelData, callback) => {
  const { name, city, imgurl, price, roomtype, is_ac, food, wifi } = hotelData;
  const query = 'INSERT INTO hotels (name, city, imgurl, price, roomtype, is_ac, food, wifi) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(query, [name, city, imgurl, price, roomtype, is_ac, food, wifi], callback);
};


exports.updateHotels = (hotel_id, hotelData, callback) => {
  const { name, city, imgurl, price, roomtype, is_ac, food, wifi } = hotelData;
  const query = 'UPDATE hotels SET name = ?, city = ?, imgurl = ?, price = ?, is_ac = ?,food = ?,wifi = ?,roomtype = ? WHERE hotel_id = ?';
  db.query(query, [name, city, imgurl, price, roomtype, is_ac, food, wifi], callback);
};

exports.deleteHotels = (hotel_id, callback) => {
  const query = 'DELETE FROM hotels WHERE hotel_id = ?';
  db.query(query, [hotel_id], callback);
};
