const db = require('../connection');

exports.getAllPackages = (callback) => {
  db.query('SELECT * FROM package', callback);
};
exports.getLatestPackages = (callback) => {
  db.query('SELECT * FROM package WHERE is_latest = "1"', callback);
};
exports.getDomesticPackages = (callback) => {
  db.query('SELECT * FROM package WHERE packagetype = "Domestic"', callback);
};
exports.getInternationalPackages = (callback) => {
  db.query('SELECT * FROM package WHERE packagetype = "International"', callback);
};
exports.getWeekendPackages = (callback) => {
  db.query('SELECT * FROM package WHERE is_Weekend = "1"', callback);
};

exports.createPackage = (packageData, callback) => {
  const { title, subtitle, cost, duration, packagetype, is_latest, is_weekend, food, flight, imgurl } = packageData;
  const query = 'INSERT INTO package (title, subtitle, cost, duration, packagetype, is_latest, is_weekend, food, flight, imgurl) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(query, [title, subtitle, cost, duration, packagetype, is_latest, is_weekend, food, flight, imgurl], callback);
};


exports.updatePackage = (package_id, packageData, callback) => {
  const { title, subtitle, cost, duration, packagetype,is_latest,is_weekend,food,flight,imgurl } = packageData;
  const query = 'UPDATE package SET title = ?, subtitle = ?, cost = ?, duration = ?, icons = ? WHERE id = ?';
  db.query(query, [title, subtitle, cost, duration, packagetype,is_latest,is_weekend,food,flight,imgurl, package_id], callback);
};

exports.deletePackage = (package_id, callback) => {
  const query = 'DELETE FROM package WHERE id = ?';
  db.query(query, [package_id], callback);
};
