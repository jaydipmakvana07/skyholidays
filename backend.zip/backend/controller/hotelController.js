// travelPackageController.js
const { getAllHotels,createHotels, updateHotels, deleteHotels } = require('../model/hotelmodel');

exports.getAllHotels = (req, res) => {
  getAllHotels((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.createHotels = (req, res) => {
  createHotels(req.body, (err, result) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ id: result.insertId, ...req.body });
  });
};

exports.updateHotels = (req, res) => {
  const id = req.params.package_id;
  updateHotels(id, req.body, (err, result) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ id, ...req.body });
  });
};

exports.deleteHotels = (req, res) => {
  const id = req.params.package_id;
  deleteHotels(id, (err) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ message: 'Travel package deleted successfully' });
  });
};
