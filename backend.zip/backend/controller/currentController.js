// travelPackageController.js
const { getAllPackages,getLatestPackages,getDomesticPackages,getInternationalPackages,getWeekendPackages, createPackage, updatePackage, deletePackage } = require('../model/currentmodel');

exports.getAllPackages = (req, res) => {
  getAllPackages((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.getLatestPackages = (req, res) => {
  getLatestPackages((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.getDomesticPackages = (req, res) => {
  getDomesticPackages((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.getInternationalPackages = (req, res) => {
  getInternationalPackages((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.getWeekendPackages = (req, res) => {
  getWeekendPackages((err, results) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json(results);
  });
};
exports.createPackage = (req, res) => {
  createPackage(req.body, (err, result) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ id: result.insertId, ...req.body });
  });
};

exports.updatePackage = (req, res) => {
  const id = req.params.package_id;
  updatePackage(id, req.body, (err, result) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ id, ...req.body });
  });
};

exports.deletePackage = (req, res) => {
  const id = req.params.package_id;
  deletePackage(id, (err) => {
    if (err) {
      console.error('Error executing query: ' + err.stack);
      res.status(500).json({ error: 'Database error' });
      return;
    }
    res.json({ message: 'Travel package deleted successfully' });
  });
};
