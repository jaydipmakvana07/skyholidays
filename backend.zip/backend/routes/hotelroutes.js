// travelPackageRoutes.js
const express = require('express');
const { getAllHotels, createHotels, updateHotels, deleteHotels } = require('../controller/hotelController');

const router = express.Router();

router.get('/', getAllHotels);
router.post('/', createHotels);
router.put('/:hotel_id', updateHotels);
router.delete('/:hotel_id', deleteHotels);

module.exports = router;
