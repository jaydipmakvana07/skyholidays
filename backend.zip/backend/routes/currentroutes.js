// travelPackageRoutes.js
const express = require('express');
const { getAllPackages,getLatestPackages,getDomesticPackages,getInternationalPackages,getWeekendPackages, createPackage, updatePackage, deletePackage } = require('../controller/currentController');

const router = express.Router();

router.get('/', getAllPackages);
router.get('/latest', getLatestPackages);
router.get('/domestic', getDomesticPackages);
router.get('/international', getInternationalPackages);
router.get('/weekend', getWeekendPackages);
router.post('/', createPackage);
router.put('/:id', updatePackage);
router.delete('/:id', deletePackage);

module.exports = router;
