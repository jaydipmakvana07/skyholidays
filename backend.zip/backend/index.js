const express = require('express');
const bodyParser = require('body-parser');
const travelPackageRoutes = require('./routes/currentroutes');
const HotelRoutes = require('./routes/hotelroutes');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;
// Multer storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './upload'); // Destination folder for uploaded files
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // File naming convention
  }
});

// Multer upload configuration
const upload = multer({ storage: storage });

app.use(bodyParser.json());
app.use(cors());
app.use('/package', travelPackageRoutes);
app.use('/hotels', HotelRoutes);

// Route for uploading files
app.post('/upload', upload.single('image'), (req, res) => {
  // Handle file upload here
  res.json({ filename: req.file.filename });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
